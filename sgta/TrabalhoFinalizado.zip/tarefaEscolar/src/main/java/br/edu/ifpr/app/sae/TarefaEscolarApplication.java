package br.edu.ifpr.app.sae;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TarefaEscolarApplication {

	public static void main(String[] args) {
		SpringApplication.run(TarefaEscolarApplication.class, args);
	}

}
