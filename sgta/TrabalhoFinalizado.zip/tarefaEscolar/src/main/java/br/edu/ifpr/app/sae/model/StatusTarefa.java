package br.edu.ifpr.app.sae.model;


public enum StatusTarefa {
	
	FINALIZADA,
	AGENDADA,
	CANCELADA;

}
